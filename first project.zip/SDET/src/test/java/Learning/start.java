package Learning;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class start {

	public static void main(String[] args) throws InterruptedException {
		
		ChromeDriver driver= new ChromeDriver();
       driver.get("https://www.saucedemo.com/v1/");
       driver.manage().window().maximize();
       WebElement web= driver.findElement(By.className("form_input"));
       web.sendKeys("standard_user");
       
       web=driver.findElement(By.name("password"));
       web.sendKeys("secret_sauce");
       driver.findElement(By.className("btn_action")).click();
       driver.findElement(By.className("inventory_item_name")).click();
       driver.findElement(By.xpath("//button[.='ADD TO CART'][1]")).click();
       Thread.sleep(2000);
              
       driver.findElement(By.xpath("//div[@id=\"shopping_cart_container\"]")).click();
       driver.findElement(By.xpath("//a[.='CHECKOUT']")).click();
       Thread.sleep(2000);

       driver.findElement(By.id("first-name")).sendKeys("Pragya");
       driver.findElement(By.id("last-name")).sendKeys("Banga");	
      
       driver.findElement(By.id("postal-code")).sendKeys("201018");
       Thread.sleep(2000);

        driver.findElement(By.xpath("//input[@value='CONTINUE']")).click();
        Thread.sleep(2000);

        driver.findElement(By.xpath("//a[.='FINISH']")).click();
        
       
	}

}
