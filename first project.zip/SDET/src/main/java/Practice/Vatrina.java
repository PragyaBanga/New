package Practice;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import dev.failsafe.internal.util.Assert;

public class Vatrina {

	public static void main(String[] args) {

   ChromeDriver driver= new ChromeDriver();
   driver.get("https://vatrinawebplatform-638132-react.b440331.dev.eastus.az.svc.builder.cafe/EmailAccountRegistration");
   driver.manage().window().maximize();
   WebElement signup= driver.findElement(By.id("fullName"));
   signup.sendKeys("pragya");
   signup= driver.findElement(By.id("username"));
   signup.sendKeys("pragya_1");
   signup=driver.findElement(By.id("dateOfBirth"));
   signup.sendKeys("22-08-1998");
   signup=driver.findElement(By.id("email"));
   signup.sendKeys("pragya@yopmail.com");
   signup=driver.findElement(By.id("password"));
   signup.sendKeys("Pragya@123");
   Select s= new Select(driver.findElement(By.xpath("//input[@value='Female']")));
   s.selectByVisibleText("Female");
   driver.findElement(By.xpath("//input[@value='Female']")).isSelected();
      
   
   
   


   
   
  
    
    
    
	}
	
	
	

}
